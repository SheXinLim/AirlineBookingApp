# ISYSA3
ISYSA3

## To run this porgram
1. Download and unzip the zip files.
2. Navigate to the folder:
```
cd folder_name
```
3. Run the application(either on your local device or on the server):
```
python3 web_app.py
```
4. Using the link provided to run the web page on your browser.